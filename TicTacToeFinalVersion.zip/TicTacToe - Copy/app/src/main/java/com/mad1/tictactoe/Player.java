package com.mad1.tictactoe;

import android.text.Editable;

public class Player {
    Editable playerX;
    Editable playerO;

    public Player(Editable playerX, Editable playerO) {
        this.playerX = playerX;
        this.playerO = playerO;
    }

    public Editable getPlayerX() {
        return playerX;
    }

    public void setPlayerX(Editable playerX) {
        this.playerX = playerX;
    }

    public Editable getPlayerO() {
        return playerO;
    }

    public void setPlayerO(Editable playerO) {
        this.playerO = playerO;
    }
}
