package com.mad1.tictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView playerNameTextView;
    String playerXnameDefined = "Player X";
    String playerOnameDefined = "Player O";
    boolean currentPlayer = true;
    int stepCounter;
    int buttonCellId = 0;
    Button new_game;
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9;
    Button[][] myButtons = new Button[3][3];
    SharedPreferences savedData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playerNameTextView = (TextView) findViewById(R.id.playerNameTextView);

        //add buttons to array
        b1 = (Button)findViewById(R.id.button1);
        myButtons[0][0] = b1;
        b2 = (Button)findViewById(R.id.button2);
        myButtons[0][1] = b2;
        b3 = (Button)findViewById(R.id.button3);
        myButtons[0][2] = b3;
        b4 = (Button)findViewById(R.id.button4);
        myButtons[1][0] = b4;
        b5 = (Button)findViewById(R.id.button5);
        myButtons[1][1] = b5;
        b6 = (Button)findViewById(R.id.button6);
        myButtons[1][2] = b6;
        b7 = (Button)findViewById(R.id.button7);
        myButtons[2][0] = b7;
        b8 = (Button)findViewById(R.id.button8);
        myButtons[2][1] = b8;
        b9 = (Button)findViewById(R.id.button9);
        myButtons[2][2] = b9;

        // set buttons onclick listenner
        myButtons[0][0].setOnClickListener(this);
        myButtons[0][1].setOnClickListener(this);
        myButtons[0][2].setOnClickListener(this);
        myButtons[1][0].setOnClickListener(this);
        myButtons[1][1].setOnClickListener(this);
        myButtons[1][2].setOnClickListener(this);
        myButtons[2][0].setOnClickListener(this);
        myButtons[2][1].setOnClickListener(this);
        myButtons[2][2].setOnClickListener(this);

        savedData = getSharedPreferences("savedData",MODE_PRIVATE);

        // get new game button
        new_game = (Button)findViewById(R.id.new_game);

       // set on click listener to new game button
        new_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newGame();
            }
        });
    }

    // onclick listener is set in onCreate for buttons that use this method
    @Override
    public void onClick(View v) {
        //current player is true and x started
        if(currentPlayer){
            ((Button)v).setText("X");
            ((Button)v).setEnabled(false);
            ((Button)v).setBackgroundColor(Color.BLUE);
            ((Button)v).setTextColor(Color.BLACK);
            ((Button)v).playSoundEffect(2);
            playerNameTextView.setText(playerOnameDefined);

        }
        else{
            ((Button)v).setText("O");
            ((Button)v).setEnabled(false);
            ((Button)v).setBackgroundColor(Color.YELLOW);
            ((Button)v).setTextColor(Color.BLACK);
            ((Button)v).playSoundEffect(1);
            playerNameTextView.setText(playerXnameDefined);
        }
        stepCounter++;
        if(defineWinner()){
            if(currentPlayer){
                playerNameTextView.setText(playerXnameDefined + " Wins");
                Toast.makeText(MainActivity.this, playerXnameDefined + " Wins", Toast.LENGTH_SHORT).show();
                buttonsDisable();
            }
            else{
                playerNameTextView.setText(playerOnameDefined + " Wins");
                Toast.makeText(MainActivity.this, playerOnameDefined + " Wins", Toast.LENGTH_SHORT).show();
                buttonsDisable();
            }
        }
        else if(stepCounter == 9){
            playerNameTextView.setText("Draw");
            Toast.makeText(MainActivity.this, "Draw", Toast.LENGTH_SHORT).show();
        }
        else{
            if(currentPlayer) {
                currentPlayer = false;
            }
            else{
                currentPlayer = true;
            }
        }
    }

    // check for winner
    protected boolean defineWinner(){

        String[][] checkWin = new String[3][3];
        for(int i = 0; i < 3;i++){
            for(int a = 0; a < 3; a++){
                checkWin[i][a] = myButtons[i][a].getText().toString();
            }
        }
        //check rows
        for(int i = 0; i < 3; i++){
            if(checkWin[i][0].equals(checkWin[i][1])
                    && checkWin[i][1].equals(checkWin[i][2])
                    && !checkWin[i][0].equals("")){
                return true;
            }
        }
        //check columns
        for(int i = 0; i < 3; i++){
            if(checkWin[0][i].equals(checkWin[1][i])
                    && checkWin[0][i].equals(checkWin[2][i])
                    && !checkWin[0][i].equals("")){
                return true;
            }
        }
        // check left-right diagonal
        if(checkWin[0][0].equals(checkWin[1][1])
                && checkWin[0][0].equals(checkWin[2][2])
                && !checkWin[0][0].equals("")){
            return true;
        }

        // check right-left diagonal
        if(checkWin[0][2].equals(checkWin[1][1])
                && checkWin[0][2].equals(checkWin[2][0])
                && !checkWin[0][2].equals("")){
            return true;
        }
        return false;
    }


    // save application data in memory when current activity shasowed by screen rotation activity
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = savedData.edit();

        // save buttons values
        editor.putString("b1", myButtons[0][0].getText().toString());
        editor.putBoolean("b1_clicked", myButtons[0][0].isEnabled());
        editor.putString("b2", myButtons[0][1].getText().toString());
        editor.putBoolean("b2_clicked", myButtons[0][1].isEnabled());
        editor.putString("b3", myButtons[0][2].getText().toString());
        editor.putBoolean("b3_clicked", myButtons[0][2].isEnabled());
        editor.putString("b4", myButtons[1][0].getText().toString());
        editor.putBoolean("b4_clicked", myButtons[1][0].isEnabled());
        editor.putString("b5", myButtons[1][1].getText().toString());
        editor.putBoolean("b5_clicked", myButtons[1][1].isEnabled());
        editor.putString("b6", myButtons[1][2].getText().toString());
        editor.putBoolean("b6_clicked", myButtons[1][2].isEnabled());
        editor.putString("b7", myButtons[2][0].getText().toString());
        editor.putBoolean("b7_clicked", myButtons[2][0].isEnabled());
        editor.putString("b8", myButtons[2][1].getText().toString());
        editor.putBoolean("b8_clicked", myButtons[2][1].isEnabled());
        editor.putString("b9", myButtons[2][2].getText().toString());
        editor.putBoolean("b9_clicked", myButtons[2][02].isEnabled());

        // save variables values
        editor.putBoolean("currentPlayer", currentPlayer);
        editor.putInt("stepCounter", stepCounter);
        editor.putInt("buttonCellId",buttonCellId);

        // save buttons text colours
        int b1_text_color = myButtons[0][0].getCurrentTextColor();
        editor.putInt("b1_text_color", b1_text_color);
        int b2_text_color = myButtons[0][1].getCurrentTextColor();
        editor.putInt("b2_text_color", b2_text_color);
        int b3_text_color = myButtons[0][2].getCurrentTextColor();
        editor.putInt("b3_text_color", b3_text_color);
        int b4_text_color = myButtons[1][0].getCurrentTextColor();
        editor.putInt("b4_text_color", b4_text_color);
        int b5_text_color = myButtons[1][1].getCurrentTextColor();
        editor.putInt("b5_text_color", b5_text_color);
        int b6_text_color = myButtons[1][2].getCurrentTextColor();
        editor.putInt("b6_text_color", b6_text_color);
        int b7_text_color = myButtons[2][0].getCurrentTextColor();
        editor.putInt("b7_text_color", b7_text_color);
        int b8_text_color = myButtons[2][1].getCurrentTextColor();
        editor.putInt("b8_text_color", b8_text_color);
        int b9_text_color = myButtons[2][2].getCurrentTextColor();
        editor.putInt("b9_text_color", b9_text_color);

        // save buttons background colours
        int b1_color = ((ColorDrawable) myButtons[0][0].getBackground()).getColor();
        editor.putInt("b1_background_color", b1_color);
        int b2_color = ((ColorDrawable) myButtons[0][1].getBackground()).getColor();
        editor.putInt("b2_background_color", b2_color);
        int b3_color = ((ColorDrawable) myButtons[0][2].getBackground()).getColor();
        editor.putInt("b3_background_color",b3_color);
        int b4_color = ((ColorDrawable) myButtons[1][0].getBackground()).getColor();
        editor.putInt("b4_background_color", b4_color);
        int b5_color = ((ColorDrawable) myButtons[1][1].getBackground()).getColor();
        editor.putInt("b5_background_color",b5_color);
        int b6_color = ((ColorDrawable) myButtons[1][2].getBackground()).getColor();
        editor.putInt("b6_background_color",b6_color);
        int b7_color = ((ColorDrawable) myButtons[2][0].getBackground()).getColor();
        editor.putInt("b7_background_color", b7_color);
        int b8_color = ((ColorDrawable) myButtons[2][1].getBackground()).getColor();
        editor.putInt("b8_background_color",b8_color);
        int b9_color = ((ColorDrawable) myButtons[2][2].getBackground()).getColor();

        editor.putInt("b9_background_color", b9_color);
        // data saved
        editor.commit();
    }

    // get application data from memory when current activity resumed
    @Override
    protected void onResume() {
        super.onResume();

        // get buttons values
        b1.setText(savedData.getString("b1",""));
        b2.setText(savedData.getString("b2", ""));
        b3.setText(savedData.getString("b3",""));
        b4.setText(savedData.getString("b4", ""));
        b5.setText(savedData.getString("b5",""));
        b6.setText(savedData.getString("b6",""));
        b7.setText(savedData.getString("b7",""));
        b8.setText(savedData.getString("b8",""));
        b9.setText(savedData.getString("b9",""));

        // get button state
        b1.setEnabled(savedData.getBoolean("b1_clicked",true));
        b2.setEnabled(savedData.getBoolean("b2_clicked",true));
        b3.setEnabled(savedData.getBoolean("b3_clicked",true));
        b4.setEnabled(savedData.getBoolean("b4_clicked",true));
        b5.setEnabled(savedData.getBoolean("b5_clicked",true));
        b6.setEnabled(savedData.getBoolean("b6_clicked",true));
        b7.setEnabled(savedData.getBoolean("b7_clicked",true));
        b8.setEnabled(savedData.getBoolean("b8_clicked",true));
        b9.setEnabled(savedData.getBoolean("b9_clicked",true));

        // get variables values
        currentPlayer = savedData.getBoolean("currentPlayer",false);
        stepCounter = savedData.getInt("stepCounter",0);

        // get button background colors
        b1.setBackgroundColor(savedData.getInt("b1_background_color", 0));
        b2.setBackgroundColor(savedData.getInt("b2_background_color",0));
        b3.setBackgroundColor(savedData.getInt("b3_background_color",0));
        b4.setBackgroundColor(savedData.getInt("b4_background_color",0));
        b5.setBackgroundColor(savedData.getInt("b5_background_color",0));
        b6.setBackgroundColor(savedData.getInt("b6_background_color",0));
        b7.setBackgroundColor(savedData.getInt("b7_background_color",0));
        b8.setBackgroundColor(savedData.getInt("b8_background_color",0));
        b9.setBackgroundColor(savedData.getInt("b9_background_color",0));

        // get buttons text color
        b1.setTextColor(savedData.getInt("b1_text_color", 0));
        b2.setTextColor(savedData.getInt("b2_text_color", 0));
        b3.setTextColor(savedData.getInt("b3_text_color", 0));
        b4.setTextColor(savedData.getInt("b4_text_color", 0));
        b5.setTextColor(savedData.getInt("b5_text_color", 0));
        b6.setTextColor(savedData.getInt("b6_text_color", 0));
        b7.setTextColor(savedData.getInt("b7_text_color", 0));
        b8.setTextColor(savedData.getInt("b8_text_color", 0));
        b9.setTextColor(savedData.getInt("b9_text_color", 0));
    }

    //Read Data From Intent passed from PlayerNameInput activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

            // if data received assign data to variables and textveiw
            if(resultCode == PlayersNameInput.RESULT_OK){
                playerXnameDefined =data.getStringExtra("playerX");
                playerOnameDefined = data.getStringExtra("playerO");
                playerNameTextView.setText(playerXnameDefined);
                // maintenance purpose line of code
                System.out.println(playerXnameDefined);
            }
            // assign names to textview depending on turn if game have started already
            if(stepCounter % 2 == 0){
                playerNameTextView.setText(playerXnameDefined);
            }
            if(stepCounter % 2 != 0){
                playerNameTextView.setText(playerOnameDefined);
            }

    }
    // menu implementation
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.settings){
            Toast.makeText(MainActivity.this, "Settings Menu", Toast.LENGTH_SHORT).show();
        }
        //pick change name activity this opens another activity to a user
        else if(id == R.id.enter_names){
            Intent intent = new Intent(this,PlayersNameInput.class);
            startActivityForResult(intent,1);
        }
        // reset game in the menu
        else if(id == R.id.reset){
            newGame();
        }
        return true;
    }

    // disable buttons
    public void buttonsDisable(){
        for(int row = 0; row < 3; row++){
            for(int col = 0; col < 3; col++){
                if(myButtons[row][col].isEnabled()) {
                    myButtons[row][col].setEnabled(false);
                }
            }
        }
    }

    // enable buttons and reset game
    public void  newGame(){
        for(int row = 0; row < 3; row++){
            for(int col = 0; col < 3; col++){
                myButtons[row][col].setText("");
                myButtons[row][col].setEnabled(true);
                myButtons[row][col].setBackgroundColor(Color.LTGRAY);
            }
        }
        playerNameTextView.setText(playerXnameDefined);
        stepCounter = 0;
        currentPlayer = true;
    }
    // used this method because i could not save data in onPause method in times when it was passed from PlayerNameInput activity
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("playerXname" ,playerXnameDefined);
        outState.putString("playerOname", playerOnameDefined);
        outState.putString("textViewName", playerNameTextView.getText().toString());

    }
    // restore data when game resumed
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
       playerXnameDefined = savedInstanceState.getString("playerXname");
       playerOnameDefined = savedInstanceState.getString("playerOname");
       playerNameTextView.setText(savedInstanceState.getString("textViewName"));
    }


}