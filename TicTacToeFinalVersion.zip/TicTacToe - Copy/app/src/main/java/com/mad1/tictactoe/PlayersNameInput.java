package com.mad1.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PlayersNameInput extends AppCompatActivity {

    EditText playerX;
    EditText playerO;
    Button toMain;
    SharedPreferences savedData;
    String x = "";
    String o ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players_name_input);
        playerX = (EditText) findViewById(R.id.editTextPlayerX);
        playerO = (EditText) findViewById(R.id.editTextPlayerO);
        toMain = (Button) findViewById(R.id.add_players);
        savedData = getSharedPreferences("savedData",MODE_PRIVATE);
        addPlayers();
    }

    // save activity data in memory
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = savedData.edit();
        editor.putString("playerX", playerX.getText().toString());
        editor.putString("playerO", playerO.getText().toString());
    }

    // release activity data when it is active again
    @Override
    protected void onResume() {
        super.onResume();
        x = savedData.getString("playerX","");
        o = savedData.getString("playerO","");
    }
    // pass player inputs to main activity
    protected void addPlayers(){
       final Player players = new Player(playerX.getText(), playerO.getText());
       // set onclick listenner
       toMain.setOnClickListener(
               new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       // check if players name not left blank
                       if(playerX.getText().toString().equals("") || playerO.getText().toString().equals("")) {
                           clearEditTextViews();
                           Toast.makeText(PlayersNameInput.this, "Enter Player Name Please", Toast.LENGTH_SHORT).show();
                       }
                       // check if players name match
                       else if(playerX.getText().toString().equalsIgnoreCase(playerO.getText().toString())){
                           clearEditTextViews();
                           Toast.makeText(PlayersNameInput.this, playerX.getText() + "Names Match Try Again", Toast.LENGTH_SHORT).show();
                       }
                       else{
                           x = playerX.getText().toString();
                           o = playerO.getText().toString();
                           // return players Names to main activity
                           Intent returnIntent = new Intent(".MainActivity");
                           returnIntent.putExtra("playerX", x);
                           returnIntent.putExtra("playerO", o);
                           // pass data
                           setResult(Activity.RESULT_OK, returnIntent);
                           // close previous intent
                           finish();
                       }
                   }
               }
       );
    }
    // reset text fields if user name input wrong
    protected void clearEditTextViews(){
        playerX.setText("");
        playerO.setText("");
    }


}